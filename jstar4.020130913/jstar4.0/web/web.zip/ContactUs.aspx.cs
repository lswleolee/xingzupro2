﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class ContactUs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            OnSetLanguage();
            DBLL.clsTopicCategory clstopc = new DBLL.clsTopicCategory();
            DataTable dt = clstopc.Select_tb_TopicCategoryBynTopicID(7);
            if (dt != null)
            {
                TreeListBar1.TopicCateDataTable = new Model.dsTopic.tb_TopicCategoryDataTable();
                TreeListBar1.TopicCateDataTable.Merge(dt);
                TreeListBar1.RedirectUrl = "ContactUs.aspx";
            }

            DBLL.OptionSysDBLL option = new DBLL.OptionSysDBLL();
            if (Session["languageGlobal"] == "en")
            {

                divContactus.InnerHtml = option.GetOptionValue("en", "SystemSetting", "ContactInformation");
            }
            else if (Session["languageGlobal"] == "cn")
            {
                divContactus.InnerHtml = option.GetOptionValue("cn", "SystemSetting", "ContactInformation");
            }

        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtCompanyName.Text.Length > 0 && txtPhone.Text.Length > 0 && txtsEmail.Text.Length > 0 && txtsContent.Text.Length > 0)
            {
                DBLL.clsContact clscontact = new DBLL.clsContact();
                int nID = clscontact.insert_tb_Contact(txttitle.Text, txtFName.Text + txtLName.Text, txtCompanyName.Text, txtAddress.Text, txtsEmail.Text,
                      txtFax.Text, txtPhone.Text, txtsContent.Text, "client", DateTime.Now, "client", DateTime.Now, true, 0,false);
            }
            else
            {
                if (Session["languageGlobal"] == "en")
                {
                    ShowMsg1.TitleName = "SYSTEM MESSAGE";
                    ShowMsg1.InnerContent = "Please input CompanyName,,Phone,Email and Content ！";
                }
                else
                {
                    ShowMsg1.TitleName = "系统提示";
                    ShowMsg1.InnerContent = "请输入公司,电话,油箱,内容等主要信息！";
                }
                ShowMsg1.Show();
            }
        }
        catch (Exception)
        {
            
            throw;
        }
    }
    public void OnSetLanguage()
    {
        string xmlfilepath = ConfigurationManager.AppSettings["xmlfilepath"].ToString();
        if (Session["languageGlobal"] != null)
        {
            xmlfilepath = xmlfilepath.Replace("[filename]", Session["languageGlobal"].ToString());

        }
        else
        {
            xmlfilepath = xmlfilepath.Replace("[filename]", "en");


        }
        clslang langxml = new clslang(xmlfilepath);
        langxml.XmlLoad();

        //Label
        // lblAdd_Education_News.Text = langxml.getString("AddNews", "Label", "lblAdd_Education_News");
        //button
        lblCONTACTUSTitle.Text = langxml.getString("ContactUs", "Label", "lblCONTACTUSTitle");
        //btnSearch.Text = langxml.getString("MasterPage", "Button", "btnSearch");
    }
}