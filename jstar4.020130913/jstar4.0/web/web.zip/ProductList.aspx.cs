﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
public partial class ProductList : System.Web.UI.Page
{
    public Model.dsProduct.tb_ProductDataTable DataTableProduct
    {
        set { ViewState["DataTableProductProductList"] = value; }
        get
        {
            if (ViewState["DataTableProductProductList"] == null)
                ViewState["DataTableProductProductList"] = new Model.dsProduct.tb_ProductDataTable();
            return (Model.dsProduct.tb_ProductDataTable)ViewState["DataTableProductProductList"];
        }
    }
    public int nProductSelectedID
    {
        set { ViewState["nProductSelectedIDProductList"] = value; }
        get
        {
            if (ViewState["nProductSelectedIDProductList"] == null)
                ViewState["nProductSelectedIDProductList"] = 0;
            return (int)ViewState["nProductSelectedIDProductList"];
        }
    }
    public DataTable DataTableSelectedProduct
    {
        set { ViewState["DataTableSelectedProductProductList"] = value; }
        get
        {
            if (ViewState["DataTableSelectedProductProductList"] == null)
                ViewState["DataTableSelectedProductProductList"] = new DataTable();
            return (DataTable)ViewState["DataTableSelectedProductProductList"];
        }
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            OnSetLanguage();
            DataPager1.PageSize = common.GetGridViewPageCount();
            DBLL.DBcommon dbcom = new DBLL.DBcommon();
            Model.dsProduct.tb_ProductCategoryDataTable ProductList = new Model.dsProduct.tb_ProductCategoryDataTable();
            ProductList.Merge(dbcom.selectNormalTableofAll(false, "tb_ProductCategory"));

            ddlProductCateTreelist1.ProductList = ProductList;

            DBLL.clsProductCategory clspdc = new DBLL.clsProductCategory();
            Model.dsProduct.tb_ProductCategoryDataTable pcdt = new Model.dsProduct.tb_ProductCategoryDataTable();

            pcdt.Merge(clspdc.sp_selectNormalTableOfAllByProductCategory(false));

            BLL.TreeViewFromTableBLL tvfbll = new BLL.TreeViewFromTableBLL();

            tvfbll.nRootParentID = 0;
            tvfbll.FatherIDColumnName = pcdt.nParentCategoryIDColumn.ColumnName;
            //   tvfbll.NavigateUrlColumnName = "ProductList.aspx?nProductCategoryIDColumn=" + pcdt.nProductCategoryIDColumn.ColumnName;
            tvfbll.NodeValueColumnName = pcdt.nProductCategoryIDColumn.ColumnName;
            if (Session["languageGlobal"] == "en") tvfbll.NodeTextColumnName = pcdt.sProductCategoryNameENColumn.ColumnName;
            else if (Session["languageGlobal"] == "cn") tvfbll.NodeTextColumnName = pcdt.sProductCategoryNameCNColumn.ColumnName;
            tvfbll.bIsClick = true;

            TreeNode[] nodepages = tvfbll.GetTreeNodes(pcdt);
            TreeView1.Nodes.Clear();
            if (nodepages != null && nodepages.Length > 0)
            {
                for (int i = 0; i < nodepages.Length; i++)
                {

                    TreeView1.Nodes.Add(nodepages[i]);
                }
            }
            TreeView1.ExpandDepth = 0;


            //Product
            if (Session["SearchProduct"] != null && Session["SearchProduct"].ToString().Length > 0)
            {
                SeacrhProcut(Session["SearchProduct"].ToString());
                Session["SearchProduct"] = "";
            }
            else if (Session["nViewProductID"] != null && Session["nViewProductID"].ToString().Length > 0)
            {
                int nVID=0;

                if (int.TryParse(Session["nViewProductID"].ToString(), out nVID) && nVID > 0)
                {

                    SetPanel(2);
                    DBLL.clsProduct clspro = new DBLL.clsProduct();
                    DataTable pro = clspro.Select_tb_ProductBynProductID(nVID);
                    BindProductDetail(pro);
                }
                else
                {
                    SetPanel(1);
                }
                Session["nViewProductID"] = "";
            }
            else if (DataTableSelectedProduct != null && DataTableSelectedProduct.Rows.Count > 0)
            {
                SetPanel(3);
                dlProductselected.DataSource = DataTableSelectedProduct;
                dlProductselected.DataBind();
            }

            else if (nProductSelectedID > 0)
            {
                SetPanel(2);
                DBLL.clsProduct clspro = new DBLL.clsProduct();
                DataTable pro = clspro.Select_tb_ProductBynProductID(nProductSelectedID);
                BindProductDetail(pro);
            }

            else
            {
                SetPanel(1);
                if (DataTableProduct != null && DataTableProduct.Rows.Count > 0)
                {

                    lvProduct.DataSource = DataTableProduct;
                    lvProduct.DataBind();
                }
                else
                {
                    int _nID = 0;
                    if (Session["nProductCategoryIDColumn"] != null && int.TryParse(Session["nProductCategoryIDColumn"].ToString(), out _nID) && _nID > 0)
                    {
                        // DBLL.clsProductCategory clspdc = new DBLL.clsProductCategory();

                        BindProductListByCateID(_nID);
                    }
                    else
                    {
                        DBLL.clsProduct clsp = new DBLL.clsProduct();
                        DataTable dtproduct = clsp.sp_selectNormalTableOfAllByProduct(false);
                        if (dtproduct != null)
                            DataTableProduct.Merge(dtproduct);
                        lvProduct.DataSource = DataTableProduct;
                        lvProduct.DataBind();
                    }
                }
            }
        }
    }
    public void SetPanel(int nNO)
    {
        switch (nNO)
        {
            case 1:
                {
                    PnlProductList.Visible = true;
                    PnlDetail.Visible = false;
                    PnlInquire.Visible = false;
                    break;
                }
            case 2:
                {
                    PnlProductList.Visible = false;
                    PnlDetail.Visible = true;
                    PnlInquire.Visible = false;
                    break;
                }
            case 3:
                {
                    PnlProductList.Visible = false;
                    PnlDetail.Visible = false;
                    PnlInquire.Visible = true;
                    break;
                }
            default:
                break;
        }
    }
    public void BindProductListByCateID(int CateID)
    {
        DBLL.clsProductCategory clspdc = new DBLL.clsProductCategory();
        DataTable dtpdc = clspdc.Select_tb_ProductCategoryBynProductCategoryID(CateID);
        if (dtpdc != null && dtpdc.Rows.Count > 0)
        {

            Session["nProductCategoryIDColumn"] = "";
            if (Session["languageGlobal"] == "en")
            {
                ProductContent1.InnerHtml = dtpdc.Rows[0]["sContentEN"].ToString();
                lblBigTitle.Text = dtpdc.Rows[0]["sProductCategoryNameEN"].ToString();
            }
            else if (Session["languageGlobal"] == "cn")
            {
                lblBigTitle.Text = dtpdc.Rows[0]["sProductCategoryNameCN"].ToString();
                ProductContent1.InnerHtml = dtpdc.Rows[0]["sContentCN"].ToString();
            }
            DBLL.clsProduct clsp = new DBLL.clsProduct();
            DataTable dtproduct = clsp.Select_tb_ProductBynParentCategoryID(CateID);
            DataTableProduct = new Model.dsProduct.tb_ProductDataTable();
            if (dtproduct != null)
                DataTableProduct.Merge(dtproduct);

            lvProduct.DataSource = DataTableProduct;
            lvProduct.DataBind();



        }
    }
    public void BindProductDetail(DataTable pro)
    {
        if (pro != null && pro.Rows.Count > 0)
        {

            DBLL.clsProductCategory clspdc = new DBLL.clsProductCategory();
            Model.dsProduct.tb_ProductDataTable mpro = new Model.dsProduct.tb_ProductDataTable();
            mpro.Merge(pro);
            Model.dsProduct.tb_ProductRow prorow = (Model.dsProduct.tb_ProductRow)mpro.Rows[0];
            nProductSelectedID = prorow.nProductID;
            DataTable dtpdc = clspdc.Select_tb_ProductCategoryBynProductCategoryID(prorow.nProductCategoryID);
            string nCateName = "";
            if (dtpdc != null && dtpdc.Rows.Count > 0)
            {
                if (Session["languageGlobal"] == "en")
                {
                    nCateName = dtpdc.Rows[0]["sProductCategoryNameEN"].ToString();
                }
                else nCateName = dtpdc.Rows[0]["sProductCategoryNameCN"].ToString();
            }

            if (Session["languageGlobal"] == "en")
            {

                lblProductName.Text = prorow.sProductNameEN;
                lblProductType.Text = nCateName;
                lblPlaceoforigin.Text = prorow.sPlaceoforiginEN;
                lblModelNo.Text = prorow.sModelNoEN;
                lblPriceTerms.Text = prorow.sPriceTermsEN;
                lblPaymentTerms.Text = prorow.sPaymentTermsEN;
                lblPackage.Text = prorow.sPackageEN;
                lblDeliveryTime.Text = prorow.sDeliveryTimeEN;
                lblBrandName.Text = prorow.sBrandNameEN;
                divProductInfo.InnerHtml = prorow.sIntroEN;
            }
            else
            {
                lblModelNo.Text = prorow.sModelNoCN;
                lblProductName.Text = prorow.sProductNameCN;
                lblProductType.Text = nCateName;
                lblPlaceoforigin.Text = prorow.sPlaceoforiginCN;

                lblPriceTerms.Text = prorow.sPriceTermsCN;
                lblPaymentTerms.Text = prorow.sPaymentTermsCN;
                lblPackage.Text = prorow.sPackageCN;
                lblDeliveryTime.Text = prorow.sDeliveryTimeCN;
                lblBrandName.Text = prorow.sBrandNameCN;
                divProductInfo.InnerHtml = prorow.sIntroCN;
            }


            if (prorow.nProductID > 0)
            {
                DBLL.clsProduct clspd = new DBLL.clsProduct();
                DBLL.clsProductImage clspi = new DBLL.clsProductImage();
                DataTable _dtImage1 = clspi.Select_tb_ProductImageBynProductID(prorow.nProductID);
                Model.dsProduct.tb_ProductImageDataTable pidt = new Model.dsProduct.tb_ProductImageDataTable();
                if (_dtImage1 != null && _dtImage1.Rows.Count > 0) pidt.Merge(_dtImage1);

                if (pidt.Rows.Count > 0)
                {
                    Model.dsProduct.tb_ProductImageRow pirow = (Model.dsProduct.tb_ProductImageRow)pidt.Rows[0];
                    IMGbig.ImageUrl = pirow.sPImagePath;

                    if (pidt.Rows.Count > 4)
                    {
                        for (int i = 4; i < pidt.Rows.Count; i++)
                        {
                            DataRow row = pidt.Rows[i];
                            pidt.Rows.Remove(row);
                        }
                    }

                    dlsmallimglist.DataSource = pidt;
                    dlsmallimglist.DataBind();
                }
            }

        }
    }
    public void OnSetLanguage()
    {
        string xmlfilepath = ConfigurationManager.AppSettings["xmlfilepath"].ToString();
        if (Session["languageGlobal"] != null)
        {
            xmlfilepath = xmlfilepath.Replace("[filename]", Session["languageGlobal"].ToString());

        }
        else
        {
            xmlfilepath = xmlfilepath.Replace("[filename]", "en");


        }
        clslang langxml = new clslang(xmlfilepath);
        langxml.XmlLoad();

        //Label
        // lblAdd_Education_News.Text = langxml.getString("AddNews", "Label", "lblAdd_Education_News");
        //button
        lblBigTitle.Text = langxml.getString("ProductList", "Label", "lblBigTitle");
        lblPRODUCTLIST.Text = langxml.getString("ProductList", "Label", "lblPRODUCTLIST");
        //btnSearch.Text = langxml.getString("MasterPage", "Button", "btnSearch");
    }
    protected void TreeView1_SelectedNodeChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < this.TreeView1.Nodes.Count; i++)
        {//跌迭根节点
            if (this.TreeView1.SelectedNode.Parent == null)
            {
                if (this.TreeView1.SelectedValue == this.TreeView1.Nodes[i].Value)
                {//如果选中的是根节点,就展开

                    this.TreeView1.SelectedNode.Expanded = true;
                }
                else
                {//如果选中的不是根节点


                    this.TreeView1.Nodes[i].Expanded = false;

                }
            }
        }
        int _nProID = 0;
        if (int.TryParse(this.TreeView1.SelectedValue, out _nProID) && _nProID > 0)
        {
            SetPanel(1);
            BindProductListByCateID(_nProID);
            nProductSelectedID = 0;
            DataTableSelectedProduct.Clear();
        }
        //if (TreeView1.SelectedNode.Expanded == true)
        //{
        //    TreeView1.SelectedNode.Expanded = false;
        //}
        //else TreeView1.SelectedNode.Expanded = true;
    }
    protected void lvProduct_ItemEditing(object sender, ListViewEditEventArgs e)
    {
        try
        {

        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void listviewchk_CheckedChanged(object sender, EventArgs e)
    {

        CheckBox checkbox = (CheckBox)sender;
        ListViewDataItem row = (ListViewDataItem)checkbox.NamingContainer;
        ///string codeCursor = lvProduct.DataKeys[row.DataItemIndex]["学科代码"].ToString();
        Label lblnID = (Label)row.FindControl("lblnID");
        DataRow[] rrows = DataTableProduct.Select("nProductID=" + lblnID.Text.Trim());
        if (checkbox.Checked == true)
        {
            foreach (DataRow rrow in rrows)
            {
                rrow["bSelected"] = true;
            }
        }
        else
        {
            foreach (DataRow rrow in rrows)
            {
                rrow["bSelected"] = false;
            }
        }
        //lvProduct.DataSource = DataTableProduct;
        //lvProduct.DataBind();

    }
    protected void lvProduct_ItemUpdating(object sender, ListViewUpdateEventArgs e)
    {
        DBLL.clsProductImage clspimg = new DBLL.clsProductImage();

        Model.dsProduct.tb_ProductSelectedDataTable psdt = new Model.dsProduct.tb_ProductSelectedDataTable();
        foreach (DataRow rrow in DataTableProduct.Rows)
        {
            Model.dsProduct.tb_ProductRow prow = DataTableProduct.Newtb_ProductRow();
            prow = (Model.dsProduct.tb_ProductRow)rrow;
            //CheckBox cbSelected=( CheckBox)  item.FindControl("cbSelected");
            if (prow.bSelected == true)
            {
                //Label lblnID = (Label)item.FindControl("lblnID");
                //LinkButton lblsProductNameEN = (LinkButton)item.FindControl("lblsProductNameEN");
                //LinkButton lblsProductNameCN = (LinkButton)item.FindControl("lblsProductNameCN");
                //Image Image1 = (Image)item.FindControl("Image1");


                Model.dsProduct.tb_ProductSelectedRow row = psdt.Newtb_ProductSelectedRow();
                row.nProductID = prow.nProductID;
                row.sProductNameCN = prow.sProductNameCN;
                row.sProductNameEN = prow.sProductNameEN;


                string ImageUrlpath = "";
                DataTable dtimgs = clspimg.Select_tb_ProductImageBynProductID(prow.nProductID);
                if (dtimgs != null && dtimgs.Rows.Count > 0)
                {
                    ImageUrlpath = dtimgs.Rows[0]["sPImagePath"].ToString();
                }
                row.sPImagePath = ImageUrlpath;
                psdt.Rows.Add(row);
            }
        }
        if (psdt.Rows.Count < 1)
        {
            Label lblnID = (Label)lvProduct.Items[e.ItemIndex].FindControl("lblnID");
            LinkButton lblsProductNameEN = (LinkButton)lvProduct.Items[e.ItemIndex].FindControl("lblsProductNameEN");
            LinkButton lblsProductNameCN = (LinkButton)lvProduct.Items[e.ItemIndex].FindControl("lblsProductNameCN");
            Image Image1 = (Image)lvProduct.Items[e.ItemIndex].FindControl("Image1");

            Model.dsProduct.tb_ProductSelectedRow row = psdt.Newtb_ProductSelectedRow();
            row.nProductID = int.Parse(lblnID.Text.Trim());
            row.sProductNameCN = lblsProductNameCN.Text.Trim();
            row.sProductNameEN = lblsProductNameEN.Text.Trim();
            row.sPImagePath = Image1.ImageUrl;
            psdt.Rows.Add(row);
        }
        if (psdt.Rows.Count > 0)
        {
            SetPanel(3);
            dlProductselected.DataSource = psdt;
            dlProductselected.DataBind();
        }

    }
    protected void lvProduct_SelectedIndexChanging(object sender, ListViewSelectEventArgs e)
    {
        Label lblnID = (Label)lvProduct.Items[e.NewSelectedIndex].FindControl("lblnID");
        int _nID = 0;
        DBLL.clsProductCategory ProductCategory = new DBLL.clsProductCategory();
        if (int.TryParse(lblnID.Text.Trim(), out _nID) && _nID > 0)
        {
            SetPanel(2);
            DBLL.clsProduct clspro = new DBLL.clsProduct();

            DataTable pro = clspro.Select_tb_ProductBynProductID(_nID);
            DataTableProduct.Clear();
            DataTableSelectedProduct.Clear();
            BindProductDetail(pro);
        }
    }
    protected void lvProduct_ItemDataBound(object sender, ListViewItemEventArgs e)
    {
        try
        {
            Label lblnID = (Label)e.Item.FindControl("lblnID");
            Image Image1 = (Image)e.Item.FindControl("Image1");
            LinkButton lblsProductNameEN = (LinkButton)e.Item.FindControl("lblsProductNameEN");
            LinkButton lblsProductNameCN = (LinkButton)e.Item.FindControl("lblsProductNameCN");
            if (Session["languageGlobal"] == "en")
            {
                lblsProductNameEN.Visible = true;
                lblsProductNameCN.Visible = false;
            }
            else
            {
                lblsProductNameEN.Visible = false;
                lblsProductNameCN.Visible = true;
            }

            int _nID = 0;
            DBLL.clsProductCategory ProductCategory = new DBLL.clsProductCategory();
            if (int.TryParse(lblnID.Text.Trim(), out _nID) && _nID > 0)
            {
                DBLL.clsProduct clspd = new DBLL.clsProduct();
                DBLL.clsProductImage clspi = new DBLL.clsProductImage();
                DataTable _dtImage1 = clspi.Select_tb_ProductImageBynProductID(_nID);
                Model.dsProduct.tb_ProductImageDataTable pidt = new Model.dsProduct.tb_ProductImageDataTable();
                if (_dtImage1 != null && _dtImage1.Rows.Count > 0) pidt.Merge(_dtImage1);

                if (pidt.Rows.Count > 0)
                {
                    Model.dsProduct.tb_ProductImageRow pirow = (Model.dsProduct.tb_ProductImageRow)pidt.Rows[0];
                    Image1.ImageUrl = pirow.sPImagePath;
                }
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {

            DBLL.clsInquiry clsi = new DBLL.clsInquiry();
            int _nSex = int.Parse(rblSex.SelectedValue.ToString());
            string sPlist = "";
            foreach (DataListItem item in dlProductselected.Items)
            {
                Label lblpID = (Label)item.FindControl("lblpID");
                sPlist += lblpID.Text.Trim();
                sPlist += ",";
            }
            sPlist = sPlist.Remove(sPlist.LastIndexOf(","));
            int _nID = clsi.insert_tb_Inquiry(txtFName.Text, txtLName.Text, _nSex, txtsEmail.Text, txtsSubject.Text, txtsMessage.Text, txtsCountry.Text, sPlist, "system", DateTime.Now, "", DateTime.Now, true, 1,false);


        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void lvProduct_PagePropertiesChanged(object sender, EventArgs e)
    {

        DBLL.OptionSysDBLL option = new DBLL.OptionSysDBLL();
        int nPageSize = 0;

        if (int.TryParse(option.GetOptionValue("FormatSetting", "GridViewFormat", "RowsCountDefault"), out nPageSize))
        {
            DataPager1.PageSize = nPageSize;
            DataPager1.SetPageProperties(DataPager1.StartRowIndex, nPageSize, true);
        }
        else
        {
            DataPager1.SetPageProperties(DataPager1.StartRowIndex, common.GetGridViewPageCount(), true);
        }

        lvProduct.DataSource = DataTableProduct;
        lvProduct.DataBind();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {

        SeacrhProcut(txtSearch.Text.Trim());
        
    }
    public void SeacrhProcut(string sSearch)
    {
        DBLL.clsProduct clspdc = new DBLL.clsProduct();
        DataTable dtpdc =new DataTable();
        if (ddlProductCateTreelist1.nSelectProductCategoryID > 0)
        {
            dtpdc = clspdc.Select_tb_ProductBynParentCategoryID(ddlProductCateTreelist1.nSelectProductCategoryID);
        }
        else dtpdc = clspdc.sp_selectNormalTableOfAllByProduct(false);
        if (dtpdc != null && dtpdc.Rows.Count > 0)
        {
            Model.dsProduct.tb_ProductDataTable dtSearchpdc = new Model.dsProduct.tb_ProductDataTable();
            string cmd = "sProductNameCN like '%" + sSearch + "%' ";
            cmd += " or ";
            cmd += "sProductNameEN like '%" + sSearch + "%' ";
            cmd += " or ";
            cmd += "sSummaryCN like '%" + sSearch + "%' ";
            cmd += " or ";
            cmd += "sSummaryEN like '%" + sSearch + "%' ";
            DataRow[] rows = dtpdc.Select(cmd);
            foreach (DataRow row in rows)
            {
                Model.dsProduct.tb_ProductRow Searchrow = dtSearchpdc.Newtb_ProductRow();
                foreach (DataColumn col in dtpdc.Columns)
                {
                    Searchrow[col.ColumnName] = row[col.ColumnName];
                }
                dtSearchpdc.Rows.Add(Searchrow);
            }
            DataTableProduct = new Model.dsProduct.tb_ProductDataTable();
            if (dtSearchpdc != null)
                DataTableProduct.Merge(dtSearchpdc);

            string xmlfilepath = ConfigurationManager.AppSettings["xmlfilepath"].ToString();
            if (Session["languageGlobal"] != null)
            {
                xmlfilepath = xmlfilepath.Replace("[filename]", Session["languageGlobal"].ToString());

            }
            else
            {
                xmlfilepath = xmlfilepath.Replace("[filename]", "en");


            }
            clslang langxml = new clslang(xmlfilepath);
            langxml.XmlLoad();

            //Label
            divProductInfo.InnerHtml = langxml.getString("ProductList", "Label", "ProductSearchListTitle");

            lvProduct.DataSource = DataTableProduct;
            lvProduct.DataBind();
        }
        SetPanel(1);
    }
    protected void dlsmallimglist_ItemCommand(object source, DataListCommandEventArgs e)
    {
        try
        {
            IMGbig.ImageUrl = e.CommandArgument.ToString();
        }
        catch (Exception)
        {
            
            throw;
        }
    }
}