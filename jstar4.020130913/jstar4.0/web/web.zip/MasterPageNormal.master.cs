﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class MasterPageNormal : System.Web.UI.MasterPage
{
    string xmlfilepath = "language\\[filename].xml";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["languageGlobal"] == null || Session["languageGlobal"].ToString().Length < 2)
            {
                Session["languageGlobal"] = "en";
            }
            DBLL.OptionSysDBLL option1 = new DBLL.OptionSysDBLL();
            DataTable dtchat =
                option1.GetOptionKeyAndValue("Message", "ChatOnline");
            gvChat.DataSource = dtchat;
            gvChat.DataBind();

            DBLL.clsTopicCategory clstc = new DBLL.clsTopicCategory();
            DBLL.DBcommon dbcom = new DBLL.DBcommon();

            Menu1.Items.Clear();
            DataTable dtMenu = dbcom.selectNormalTableofAll(false, "tb_Topic");
            DataView dvTemp = dtMenu.DefaultView;
            dvTemp.Sort = "nTopicID asc";
            dtMenu = dvTemp.ToTable();
            if (dtMenu != null)
            {
                if (Session["languageGlobal"] == "en")
                {
                    MenuItem item = new MenuItem("HomePage", "0");
                    Menu1.Items.Add(item);
                }

                else if (Session["languageGlobal"] == "cn")
                {
                    MenuItem item = new MenuItem("首页", "0");
                    Menu1.Items.Add(item);
                }


                foreach (DataRow row in dtMenu.Rows)
                {

                    string url = "";
                    switch (row["nTopicID"].ToString())
                    {
                        case "1":
                            {

                                url = "Aboutus.aspx";
                                DataTable dt = clstc.Select_tb_TopicCategoryBynTopicID(1);
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    url += "?nTCategoryID=" + dt.Rows[0]["nTCategoryID"].ToString();
                                }
                                break;
                            }
                        case "2":
                            {
                                url = "ProductList.aspx";
                                DataTable dt = clstc.Select_tb_TopicCategoryBynTopicID(2);
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    url += "?nTCategoryID=" + dt.Rows[0]["nTCategoryID"].ToString();
                                }
                                break;
                            }
                        case "3":
                            {
                                url = "Application.aspx";
                                DataTable dt = clstc.Select_tb_TopicCategoryBynTopicID(3);
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    url += "?nTCategoryID=" + dt.Rows[0]["nTCategoryID"].ToString();
                                }
                                break;
                            }
                        case "4":
                            {
                                url = "Support.aspx";
                                DataTable dt = clstc.Select_tb_TopicCategoryBynTopicID(4);
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    url += "?nTCategoryID=" + dt.Rows[0]["nTCategoryID"].ToString();
                                }
                                break;
                            }
                        case "5":
                            {
                                url = "Service.aspx";
                                DataTable dt = clstc.Select_tb_TopicCategoryBynTopicID(5);
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    url += "?nTCategoryID=" + dt.Rows[0]["nTCategoryID"].ToString();
                                }
                                break;
                            }
                        case "6":
                            {
                                url = "InfoCenter.aspx";
                                DataTable dt = clstc.Select_tb_TopicCategoryBynTopicID(6);
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    url += "?nTCategoryID=" + dt.Rows[0]["nTCategoryID"].ToString();
                                }
                                break;
                            }
                        case "7":
                            {
                                url = "ContactUs.aspx";
                                DataTable dt = clstc.Select_tb_TopicCategoryBynTopicID(7);
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    url += "?nTCategoryID=" + dt.Rows[0]["nTCategoryID"].ToString();
                                }
                                break;
                            }
                        default: break;
                    }
                    //Model.dsTopic.tb_TopicRow topicrow = (Model.dsTopic.tb_TopicRow)row;
                    if (Session["languageGlobal"] == "en")
                    {
                        MenuItem item = new MenuItem(row["sTopicNameEN"].ToString(), row["nTopicID"].ToString(), "", url);
                        Menu1.Items.Add(item);
                    }
                    else
                    {
                        MenuItem item = new MenuItem(row["sTopicNameCN"].ToString(), row["nTopicID"].ToString(), "", url);
                        Menu1.Items.Add(item);
                    }
                }

            }


            foreach (MenuItem item in Menu1.Items)
            {
                int _nvalue = 0;
                if (int.TryParse(item.Value, out _nvalue) && _nvalue > 0)
                {



                    DataTable dt = clstc.Select_tb_TopicCategoryBynTopicID(_nvalue);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            string url = "";
                            switch (_nvalue)
                            {
                                case 1:
                                    {
                                        url = "Aboutus.aspx";
                                        break;
                                    }
                                case 3:
                                    {
                                        url = "Application.aspx";
                                        break;
                                    }
                                case 4:
                                    {
                                        url = "Support.aspx";
                                        break;
                                    }
                                case 5:
                                    {
                                        url = "Service.aspx";
                                        break;
                                    }
                                case 6:
                                    {
                                        url = "InfoCenter.aspx";
                                        break;
                                    }
                                case 7:
                                    {
                                        url = "ContactUs.aspx";
                                        break;
                                    }
                                default: break;
                            }
                            url += "?nTCategoryID=";
                            url += row["nTCategoryID"].ToString();
                            // Model.dsTopic.tb_TopicCategoryRow tcrow = (Model.dsTopic.tb_TopicCategoryRow)row;
                            if (Session["languageGlobal"] == "en")
                            {
                                MenuItem newitem = new MenuItem(row["sTCategoryNameEN"].ToString(), row["nTCategoryID"].ToString(), "", url);
                                item.ChildItems.Add(newitem);
                            }
                            else
                            {
                                MenuItem newitem = new MenuItem(row["sTCategoryNameCN"].ToString(), row["nTCategoryID"].ToString(), "", url);
                                item.ChildItems.Add(newitem);
                            }
                        }

                    }
                    if (_nvalue == 2)
                    {
                        DBLL.clsProductCategory clsprocate = new DBLL.clsProductCategory();
                        DataTable dtprocate = clsprocate.Select_tb_ProductCategoryBynParentCategoryID(0);

                        if (dtprocate != null && dtprocate.Rows.Count > 0)
                        {
                            foreach (DataRow row in dtprocate.Rows)
                            {




                                // Model.dsTopic.tb_TopicCategoryRow tcrow = (Model.dsTopic.tb_TopicCategoryRow)row;
                                if (Session["languageGlobal"] == "en")
                                {

                                    MenuItem newitem = new MenuItem(row["sProductCategoryNameEN"].ToString(), row["nProductCategoryID"].ToString());
                                    item.ChildItems.Add(newitem);
                                }
                                else
                                {
                                    MenuItem newitem = new MenuItem(row["sProductCategoryNameCN"].ToString(), row["nProductCategoryID"].ToString());
                                    item.ChildItems.Add(newitem);
                                }
                            }

                        }
                    }

                }
            }

            OnSetLanguage();
            DBLL.clsLink clsl = new DBLL.clsLink();
            DataTable dtLink = clsl.sp_selectNormalTableOfAllByLink(false);
            dlLink.DataSource = dtLink;
            dlLink.DataBind();


            DBLL.OptionSysDBLL option = new DBLL.OptionSysDBLL();
            if (Session["languageGlobal"] == "en")
            {
                divContactInfo.InnerHtml = option.GetOptionValue("en", "SystemSetting", "ContactInformation");
            }
            else if (Session["languageGlobal"] == "cn")
            {
                divContactInfo.InnerHtml = option.GetOptionValue("cn", "SystemSetting", "ContactInformation");
            }

        }
    }

    public void OnSetLanguage()
    {

        if (Session["languageGlobal"] != null)
        {
            xmlfilepath = xmlfilepath.Replace("[filename]", Session["languageGlobal"].ToString());

        }
        else
        {
            xmlfilepath = xmlfilepath.Replace("[filename]", "en");


        }
        clslang langxml = new clslang(xmlfilepath);
        langxml.XmlLoad();

        //Label
        // lblAdd_Education_News.Text = langxml.getString("AddNews", "Label", "lblAdd_Education_News");
        //button
        lblBigBannerTitle.Text = langxml.getString("MasterPage", "Label", "lblBigBannerTitle");
        lblSmallBannerTitle1.Text = langxml.getString("MasterPage", "Label", "lblSmallBannerTitle1");
        lblSmallBannerTitle2.Text = langxml.getString("MasterPage", "Label", "lblSmallBannerTitle2");
        btnSearch.Text = langxml.getString("MasterPage", "Button", "btnSearch");
    }
    protected void lbtncn_Click(object sender, EventArgs e)
    {
        Session["languageGlobal"] = "cn";
        Response.Redirect(Request.RawUrl);
    }
    protected void lbtnLangen_Click(object sender, EventArgs e)
    {
        Session["languageGlobal"] = "en";
        Response.Redirect(Request.RawUrl);
    }
    protected void Menu1_Load(object sender, EventArgs e)
    {

    }
    protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
    {
        if (e.Item.Parent != null && e.Item.Parent.Value == "2")
        {
            Session["nProductCategoryIDColumn"] = e.Item.Value;
            Response.Redirect("ProductList.aspx");
        }

        if (e.Item.Value == "0")
        {
            Response.Redirect("Default.aspx");

        }
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
    }
    protected void gvChat_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblkey = (Label)e.Row.FindControl("lblkey");
                Image Image4 = (Image)e.Row.FindControl("Image4");
                if (lblkey.Text == "msn")
                {

                    Image4.ImageUrl = "~/style/images/thumb/Msn.png";

                }
                else if (lblkey.Text == "email")
                {
                    Image4.ImageUrl = "~/style/images/thumb/Email.png";
                }
            }

        }
        catch (Exception)
        {

            throw;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            Session["SearchProduct"] = txtSearch.Text;
            Response.Redirect("ProductList.aspx");

        }
        catch (Exception)
        {

            throw;
        }
    }
}
