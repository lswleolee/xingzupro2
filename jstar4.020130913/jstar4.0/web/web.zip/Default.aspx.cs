﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            OnSetLanguage();
            DBLL.OptionSysDBLL option1 = new DBLL.OptionSysDBLL();
            if (Session["languageGlobal"] == "en")
            {
                divContent1.InnerHtml = option1.GetOptionValue("en", "SystemSetting", "CustomInformation1");
                divContent2.InnerHtml = option1.GetOptionValue("en", "SystemSetting", "CustomInformation2");
                divContent3.InnerHtml = option1.GetOptionValue("en", "SystemSetting", "CustomInformation3");
            }
            else
            {
                divContent1.InnerHtml = option1.GetOptionValue("cn", "SystemSetting", "CustomInformation1");
                divContent2.InnerHtml = option1.GetOptionValue("cn", "SystemSetting", "CustomInformation2");
                divContent3.InnerHtml = option1.GetOptionValue("cn", "SystemSetting", "CustomInformation3");
            }

            DBLL.clsProductCategory clspdc = new DBLL.clsProductCategory();
            Model.dsProduct.tb_ProductCategoryDataTable pcdt = new Model.dsProduct.tb_ProductCategoryDataTable();

            pcdt.Merge(clspdc.sp_selectNormalTableOfAllByProductCategory(false));

            BLL.TreeViewFromTableBLL tvfbll = new BLL.TreeViewFromTableBLL();

            tvfbll.nRootParentID = 0;
            tvfbll.FatherIDColumnName = pcdt.nParentCategoryIDColumn.ColumnName;
           // tvfbll.NavigateUrlColumnName = "ProductList.aspx?nProductCategoryIDColumn=" + pcdt.nProductCategoryIDColumn.ColumnName;
            tvfbll.NodeValueColumnName = pcdt.nProductCategoryIDColumn.ColumnName;
            if (Session["languageGlobal"] == "en") tvfbll.NodeTextColumnName = pcdt.sProductCategoryNameENColumn.ColumnName;
            else if (Session["languageGlobal"] == "cn") tvfbll.NodeTextColumnName = pcdt.sProductCategoryNameCNColumn.ColumnName;
            tvfbll.bIsClick = true;

            TreeNode[] nodepages = tvfbll.GetTreeNodes(pcdt);
            TreeView1.Nodes.Clear();
            if (nodepages != null && nodepages.Length > 0)
            {
                for (int i = 0; i < nodepages.Length; i++)
                {

                    TreeView1.Nodes.Add(nodepages[i]);
                }
            }
            TreeView1.ExpandDepth = 0;
            
        }
    }
    protected void TreeView1_SelectedNodeChanged(object sender, EventArgs e)
    {
        Session["nProductCategoryIDColumn"] = TreeView1.SelectedNode.Value;
        Response.Redirect("ProductList.aspx");
       
      
    }
    public void OnSetLanguage()
    {
        string xmlfilepath = ConfigurationManager.AppSettings["xmlfilepath"].ToString();
        if (Session["languageGlobal"] != null)
        {
            xmlfilepath = xmlfilepath.Replace("[filename]", Session["languageGlobal"].ToString());

        }
        else
        {
            xmlfilepath = xmlfilepath.Replace("[filename]", "en");


        }
        clslang langxml = new clslang(xmlfilepath);
        langxml.XmlLoad();

        //Label
        // lblAdd_Education_News.Text = langxml.getString("AddNews", "Label", "lblAdd_Education_News");
        //button
        lblPRODUCTLISTTitle.Text = langxml.getString("Default", "Label", "lblPRODUCTLISTTitle");

        //btnSearch.Text = langxml.getString("MasterPage", "Button", "btnSearch");
    }
}