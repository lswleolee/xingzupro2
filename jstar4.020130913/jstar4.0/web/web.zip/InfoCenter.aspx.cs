﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class InfoCenter : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            OnSetLanguage();
            DBLL.clsTopicCategory clstopc = new DBLL.clsTopicCategory();
            DataTable dt = clstopc.Select_tb_TopicCategoryBynTopicID(6);
            if (dt != null)
            {
                TreeListBar1.TopicCateDataTable = new Model.dsTopic.tb_TopicCategoryDataTable();
                TreeListBar1.TopicCateDataTable.Merge(dt);
                TreeListBar1.RedirectUrl = "InfoCenter.aspx";
            }

        }
    }
    public void OnSetLanguage()
    {
        string xmlfilepath = ConfigurationManager.AppSettings["xmlfilepath"].ToString();
        if (Session["languageGlobal"] != null)
        {
            xmlfilepath = xmlfilepath.Replace("[filename]", Session["languageGlobal"].ToString());

        }
        else
        {
            xmlfilepath = xmlfilepath.Replace("[filename]", "en");


        }
        clslang langxml = new clslang(xmlfilepath);
        langxml.XmlLoad();

        //Label
        // lblAdd_Education_News.Text = langxml.getString("AddNews", "Label", "lblAdd_Education_News");
        //button
        lblINFOCENTERTitle.Text = langxml.getString("InfoCenter", "Label", "lblINFOCENTERTitle");
        //btnSearch.Text = langxml.getString("MasterPage", "Button", "btnSearch");
    }
}